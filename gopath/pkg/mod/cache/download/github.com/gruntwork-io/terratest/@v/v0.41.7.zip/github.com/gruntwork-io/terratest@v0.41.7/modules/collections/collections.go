// Package collections allows to interact with lists of things.
package collections
