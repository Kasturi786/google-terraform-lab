# AWS Lambda Function Handler Source

The lambda executable `handler` was built using

``` shell
go build lambda.go
```
