// Package k8s provides common functionalities for interacting with a Kubernetes cluster in the context of
// infrastructure testing.
package k8s
